package utility;

public interface Validatable {
    boolean validate();
}

package commands;

public interface Executable {
    boolean apply(String[] args);
}
